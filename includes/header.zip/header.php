<?php
//header.php
?>
<nav>
	<img src="images/logo.png">
	<a href="home.php">Home</a>
	<a href="about.php">About</a> 
	<a href="contact.php">Contact</a>
	<img src="images/img_311846.png" width="20" height="20">
	<select>
		<option></option>
		<option>Login</option>
		<option>Signup</option>
	</select>
</nav>
<hr>